from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, field_validator
from datetime import datetime
import os
import psycopg
from psycopg_pool import ConnectionPool

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql+psycopg://app:app@postgres:5432/telemetry")
# psycopg_pool entiende DSN sin el "+psycopg"
DSN = DATABASE_URL.replace("+psycopg", "")
pool = ConnectionPool(conninfo=DSN, min_size=1, max_size=5, open=True)

app = FastAPI(title="Ingest API", version="1.0")

# Crear tabla si no existe
DDL = """
CREATE TABLE IF NOT EXISTS telemetry_events (
  id BIGSERIAL PRIMARY KEY,
  seq BIGINT NOT NULL,
  package_id UUID NOT NULL,
  temperature_c NUMERIC(6,2) NOT NULL,
  humidity_pct NUMERIC(6,2) NOT NULL,
  g_force NUMERIC(6,2) NOT NULL,
  vibration_rms NUMERIC(6,2) NOT NULL,
  tilt_deg NUMERIC(6,2) NOT NULL,
  gps_lat NUMERIC(10,6) NOT NULL,
  gps_lon NUMERIC(10,6) NOT NULL,
  speed_kmh NUMERIC(6,2) NOT NULL,
  timestamp_emitted TIMESTAMPTZ NOT NULL,
  node_red_received_at TIMESTAMPTZ,
  ingested_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_te_ts ON telemetry_events (timestamp_emitted);
CREATE INDEX IF NOT EXISTS idx_te_seq ON telemetry_events (seq);
"""

with pool.connection() as conn:
    with conn.cursor() as cur:
        cur.execute(DDL)

class IngestPayload(BaseModel):
    seq: int
    package_id: str
    temperature_c: float
    humidity_pct: float
    g_force: float
    vibration_rms: float
    tilt_deg: float
    gps_lat: float
    gps_lon: float
    speed_kmh: float
    timestamp_emitted: datetime
    node_red_received_at: datetime | None = None

    @field_validator("package_id")
    def valid_uuid(cls, v):
        import uuid
        uuid.UUID(v)
        return v

@app.post("/ingest")
def ingest(p: IngestPayload):
    try:
        with pool.connection() as conn, conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO telemetry_events
                (seq, package_id, temperature_c, humidity_pct, g_force, vibration_rms,
                 tilt_deg, gps_lat, gps_lon, speed_kmh, timestamp_emitted, node_red_received_at)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                """,
                (
                    p.seq, p.package_id, p.temperature_c, p.humidity_pct, p.g_force,
                    p.vibration_rms, p.tilt_deg, p.gps_lat, p.gps_lon, p.speed_kmh,
                    p.timestamp_emitted, p.node_red_received_at
                )
            )
        return {"status": "ok"}
    except Exception as e:
        # Forzamos 503 para que Node-RED reintente
        raise HTTPException(status_code=503, detail=str(e))

@app.get("/health")
def health():
    return {"status": "up"}
