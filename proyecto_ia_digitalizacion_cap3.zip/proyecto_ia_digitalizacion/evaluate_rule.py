import pandas as pd
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score

# ==============================
# PARÁMETROS DEL MODELO
# ==============================
N = 3  # mismo N que en Node-RED


# ==============================
# NOMBRES DE COLUMNAS EN labels.csv
# ⚠️ CAMBIA ESTOS VALORES SI NO COINCIDEN
# ==============================

CSV_PATH = "analytics/labels.csv"

COL_PACKAGE = "package_id"     # cámbialo si en tu CSV es "id_paquete", etc.
COL_TIME    = "timestamp"      # cámbialo si se llama distinto
COL_TEMP    = "temperature_c"  # o "temperatura"
COL_G       = "g_force"        # o "fuerza_g"
COL_LABEL   = "label"          # columna 1 = incidente, 0 = no incidente


def load_data(path):
    """Carga el CSV y lo ordena por paquete y tiempo."""
    df = pd.read_csv(path)

    # Ordenamos por paquete y tiempo si existe la columna de tiempo
    if COL_TIME in df.columns:
        try:
            df[COL_TIME] = pd.to_datetime(df[COL_TIME])
        except Exception:
            print("Aviso: no he podido convertir la columna de tiempo a datetime; sigo igual.")
        df = df.sort_values(by=[COL_PACKAGE, COL_TIME]).reset_index(drop=True)
    else:
        df = df.sort_values(by=[COL_PACKAGE]).reset_index(drop=True)

    return df


def apply_rule(df, n=N):
    """
    Regla: alerta cuando (temp > 8 o g > 2.5) se mantiene durante N eventos
    consecutivos para el mismo paquete.
    """
    # Comprobamos que están las columnas necesarias
    for col in [COL_PACKAGE, COL_TEMP, COL_G, COL_LABEL]:
        if col not in df.columns:
            raise ValueError(f"La columna '{col}' no existe en labels.csv. Cámbiala en el script.")

    # 1) Condición "mala" por evento
    df["cond_mala"] = (df[COL_TEMP] > 8.0) | (df[COL_G] > 2.5)

    # 2) Columna de predicción
    df["y_pred"] = 0

    current_pkg = None
    streak = 0

    # 3) Recorremos los eventos "como si fueran llegando en tiempo real"
    for idx, row in df.iterrows():
        pkg = row[COL_PACKAGE]
        bad = row["cond_mala"]

        # Si cambia de paquete, reseteamos
        if pkg != current_pkg:
            current_pkg = pkg
            streak = 0

        if bad:
            streak += 1
        else:
            streak = 0

        df.at[idx, "y_pred"] = 1 if streak >= n else 0

    return df


def evaluate(df):
    """Calcula matriz de confusión y métricas."""
    y_true = df[COL_LABEL].astype(int)
    y_pred = df["y_pred"].astype(int)

    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()

    precision = precision_score(y_true, y_pred, zero_division=0)
    recall    = recall_score(y_true, y_pred, zero_division=0)
    f1        = f1_score(y_true, y_pred, zero_division=0)

    return {
        "tn": tn, "fp": fp, "fn": fn, "tp": tp,
        "precision": precision,
        "recall": recall,
        "f1": f1
    }


def main():
    print(f"Cargando datos desde: {CSV_PATH}")
    df = load_data(CSV_PATH)
    print(f"Eventos cargados: {len(df)}")

    print(f"\nAplicando regla con N = {N} eventos consecutivos...")
    df = apply_rule(df, N)

    print("\nCalculando métricas de clasificación...")
    m = evaluate(df)

    print("\nMatriz de confusión (filas = real, columnas = predicho):")
    print("          Pred 0    Pred 1")
    print(f"Real 0:   {m['tn']:7d}  {m['fp']:7d}")
    print(f"Real 1:   {m['fn']:7d}  {m['tp']:7d}")

    print("\nMétricas:")
    print(f"Precisión (Precision)  = {m['precision']:.3f}")
    print(f"Recall (Sensibilidad)  = {m['recall']:.3f}")
    print(f"F1-Score               = {m['f1']:.3f}")

    # Guardar CSV con predicciones
    cols = [c for c in [COL_PACKAGE, COL_TIME, COL_TEMP, COL_G, COL_LABEL] if c in df.columns]
    cols.append("y_pred")
    out_path = "analytics/predicciones_con_regla.csv"
    df[cols].to_csv(out_path, index=False)
    print(f"\nHe guardado {out_path} con las predicciones.")


if __name__ == "__main__":
    main()
