import pandas as pd
import random

# Cargar los datos simulados
df = pd.read_csv("analytics/simulated_data.csv")

# Crear columna de incidentes reales
# (simulamos que un 20% de los eventos son incidentes reales)
df["is_incident_real"] = [1 if random.random() < 0.2 else 0 for _ in range(len(df))]

# Guardar el nuevo CSV
df.to_csv("analytics/labeled_data.csv", index=False)
print("Archivo 'analytics/labeled_data.csv' creado con etiquetas simuladas.")
