import json
import random
import socket
import time
import uuid
from datetime import datetime, timezone
import paho.mqtt.client as mqtt

BROKER_HOST = "localhost"      
BROKER_PORT = 1883
TOPIC       = "greendelivery/trackers/telemetry"
QOS         = 1
INTERVAL_S  = 2

# Rangos aleatorios razonables
TEMP_RANGE_C    = (5.0, 35.0)   # °C
HUMIDITY_RANGE  = (20.0, 80.0)  # %
G_FORCE_RANGE   = (0.8, 3.5)    # g
VIB_RMS_RANGE   = (0.05, 2.5)   # g RMS
TILT_DEG_RANGE  = (0.0, 90.0)   # grados
SPEED_KMH_RANGE = (0.0, 110.0)  # km/h

START_LAT, START_LON = 40.4168, -3.7038
MAX_STEP_DEG         = 0.002

def now_iso():
    return datetime.now(timezone.utc).isoformat()

def rnd(r):
    lo, hi = r
    return round(random.uniform(lo, hi), 2)

def on_connect(client, userdata, flags, rc, properties=None):
    print(f"[MQTT] Conectado rc={rc}")

def main():
    client_id = f"tracker-sim-{socket.gethostname()}-{random.randint(1000,9999)}"
    client = mqtt.Client(client_id=client_id, protocol=mqtt.MQTTv5, transport="tcp")
    client.on_connect = on_connect
    client.connect(BROKER_HOST, BROKER_PORT, keepalive=30)
    client.loop_start()

    seq = 1
    lat, lon = START_LAT, START_LON

    try:
        while True:
            lat += random.uniform(-MAX_STEP_DEG, MAX_STEP_DEG)
            lon += random.uniform(-MAX_STEP_DEG, MAX_STEP_DEG)

            payload = {
                "seq": seq,
                "package_id": str(uuid.uuid4()),
                "temperature_c": rnd(TEMP_RANGE_C),
                "humidity_pct": rnd(HUMIDITY_RANGE),
                "g_force": rnd(G_FORCE_RANGE),
                "vibration_rms": rnd(VIB_RMS_RANGE),
                "tilt_deg": rnd(TILT_DEG_RANGE),
                "gps_lat": round(lat, 6),
                "gps_lon": round(lon, 6),
                "speed_kmh": rnd(SPEED_KMH_RANGE),
                "timestamp_emitted": now_iso()
            }
            msg = json.dumps(payload)
            res = client.publish(TOPIC, msg, qos=QOS, retain=False)
            if res.rc != mqtt.MQTT_ERR_SUCCESS:
                print(f"[MQTT] Error publicando rc={res.rc}")
            else:
                print(f"[PUB] {payload}")
            seq += 1
            time.sleep(INTERVAL_S)
    except KeyboardInterrupt:
        pass
    finally:
        client.loop_stop()
        client.disconnect()

if __name__ == "__main__":
    main()
